var express = require('express');
var fs = require('fs');
var http = require('http');
var app = express();
var mysql = require('mysql')
var head = ["<!DOCTYPE html>", "<html>", "<head>",
            "<title>Images</title>", "</head>", "<body>" ];
var tail = ["</body>", "</html>"];
var directory = "/home/cs2/jam13/public_html";
var nl = "\n";

var connection = mysql.createConnection({
  host: 'mysql-server-1',
  user: 'jam13',
  password: 'Fo8I2StlNu',
  database: 'jam13'
})

connection.connect(function(err) {
  if (err) throw err
  console.log('You are now connected...')
})



// serve static files in images/ directory
app.use(express.static(directory));

var svr = http.createServer(app);
svr.on('error', function(err) {console.log('Server: ' + err);});
svr.listen(8080);
svr.listen(0000);
